#include<iostream>
#include<stdlib.h>
using namespace std;

const int fil = 7;
const int col = 8;

bool verificar_palabra(string,char [fil][col]);
void sopa_letras(string,char [fil][col]);

int main ()
{
	string palabra, palabras_acertadas[fil*col];
    char sopa[fil][col] = { {'a','m','a','n','e','c','e','r'},
                            {'x','w','h','o','g','a','r','t'},
                            {'a','m','a','r','o','c','a','r'},
                            {'t','t','s','n','l','e','c','e'},
                            {'e','s','t','u','d','i','e','z'},
                            {'m','l','a','r','g','o','o','a'},
                            {'h','e','l','a','d','o','s','y'}
    						};

    for(int i = 0; i < fil; i++)
    {
    	for(int j = 0; j < col; j++)
        {
            cout << sopa[i][j] << "  ";
        }
        cout << endl;
    }
    cout << "\nIntroduzca la palabra que desea buscar:\n" ;
    
	do
        cin >> palabra;
    	while( palabra.length() < 3 );
		    sopa_letras(palabra,sopa);
			return 0;
}
bool verificar_palabra(string palabra,char letras[fil][col])
{
	string aux, vacia;
    int cont = 0;

    // busca palabras con tres letras en la horizontal de derecha a izquierda
        for(int i = 0; i < fil; i ++)  // for para controlar en la fila a buscar
    	{
        	for(int k = 0; k <= col-palabra.length(); k++)  // for para ir cambiando de columna para concatenar n letras diferentes
        	{
            	for(int j = k; j < palabra.length()+k; j++)  // for para buscar palabras de tama�o n entre tres y el numero de columnas que hay
            	{
                	aux +=  letras[i][j];
            	}
            	if( palabra == aux)
            	{
                	cont++;
                	return true;
            	}
            	aux = vacia;
        	}
    	}
    
	// busca palabras con tres letras en la horizontal de izquierda a derecha
        for(int i = 0; i < fil; i ++)  // for para controlar en la fila a buscar
    	{
        	for(int k = col-1; k >= palabra.length(); k--)  // for para ir cambiando de columna para concatenar tre letras diferentes
        	{
            	for(int j = k; j > k-palabra.length(); j--)  // for para buscar palabras de tama�o n entre tres y el numero de columnas que haya
            	{
                	aux +=  letras[i][j];
            	}
            	if( palabra == aux)
            	{
                	cont++;
                	return true;
            	}
            	aux = vacia;
        	}
    	}
    
	// busca palabras con tres letras en la vertical bajando
    	for(int i = 0; i < col; i ++)  // for para controlar en la columna a buscar
    	{
        	for(int k = 0; k <= fil-palabra.length(); k++)  // for para ir cambiando de fila para concatenar n letras diferentes
        	{
            	for(int j = k; j < palabra.length()+k; j++)  // for para buscar palabras de tama�o n entre tres y  el numero de columnas que haya
            	{
	                aux +=  letras[j][i];
            	}
            	if( palabra == aux)
            	{
                	cont++;
                	return true;
            	}
            	aux = vacia;
        	}
    	}

    //busca palabras con tres letras en la vertical subiendo
    	for(int i = 0; i < col; i ++)  // for para controlar en la columna a buscar
    	{
        	for(int k = fil-1; k >= palabra.length(); k--)  // for para ir cambiando de fila para concatenar tres letras diferentes
        	{
            	for(int j = k; j > k-palabra.length(); j--)  // for para buscar palabras de tama�o n entre tres y el numero de columnas que haya
            	{
            		aux +=  letras[j][i];
            	}
            	if( palabra == aux)
            	{
            		cont++;
            		return true;
            	}
        		aux = vacia;
        	}
    	}
    	if(cont == 0)
        return false;
}
void sopa_letras(string palabra,char sopa[fil][col])
{
	int acertadas = 0, erradas = 0;
    char salir;
    do
    {
    	if( verificar_palabra(palabra,sopa) )
    	{
        	cout << "\nLa palabra que ingreso, se encontro en la sopa de letras ..." << endl;
        	acertadas++;
    	}
    	else
    	{
        	cout << "\nLa palabra que ingreso, NO se encuentro en la sopa de letras... " << endl;
        	erradas++;
    	}
    	cout << "\nPresione para salir S o N si desea seguir buscando palabras:\n";
    	cin >> salir;
    	if(salir == 'n')
    	{
        	system("cls");
        	for(int i = 0; i < fil; i++)
    		{
            	for(int j = 0; j < col; j++)
            	{
                	cout << sopa[i][j] << "  ";
            	}
            	cout << endl;
        	}
        	cout << "\nPalabras encontradas: " << acertadas << "  \nPalabras NO encontradas: " << erradas << endl;
        	cout << "\nIntroduzca la palabra que desea buscar: ";
    		do
    			cin >> palabra;
    			while( palabra.length() < 3);
    	}
	}
	while(salir != 's');
    system("cls");
    cout << "\nPalabras encontradas: " << acertadas<< "  \nPalabras NO encontradas: " << erradas << endl;
    system("pause");
}

